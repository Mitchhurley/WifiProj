package wifi;
import java.io.PrintWriter;
import java.util.concurrent.ArrayBlockingQueue;

import rf.RF;

/**
 * Use this layer as a starting point for your project code.  See {@link Dot11Interface} for more
 * details on these routines.
 * @authors Mitchell Hurley & Jonah Kelsey
 * @version 1.3.1 11/17/23
 */
public class LinkLayer implements Dot11Interface 
{
    private RF theRF;           // You'll need one of these eventually
    private ArrayBlockingQueue<Frame> sendQueue;
    private ArrayBlockingQueue<Frame> ackQueue;
    private ArrayBlockingQueue<Transmission> incQueue;
    private short ourMAC;       // Our MAC address
    private PrintWriter output; // The output stream we'll write to

    private Writer writer;
    private Reader reader;

    /**
     * Constructor takes a MAC address and the PrintWriter to which our output will
     * be written.
     * @param ourMAC  MAC address
     * @param output  Output stream associated with GUI
     */
    public LinkLayer(short ourMAC, PrintWriter output) {
        // Initialize stuff
        theRF = new RF(null, null);
        sendQueue = new ArrayBlockingQueue<Frame>(10);
        ackQueue = new ArrayBlockingQueue<Frame>(10);
        incQueue = new ArrayBlockingQueue<Transmission>(10);
        this.ourMAC = ourMAC;
        this.output = output;
        // Initialize threads
        writer = new Writer(theRF, sendQueue, ackQueue, ourMAC, output);
        reader = new Reader(theRF, sendQueue, ackQueue, output, ourMAC, incQueue);
        // start threads
        Thread writerThread = new Thread(writer);
        Thread readerThread = new Thread(reader);
        writerThread.start();
        readerThread.start();

        //output.println("LinkLayer: Constructor ran.");
    }

    /**
     * Send method takes a destination, a buffer (array) of data, and the number
     * of bytes to send.  See docs for full description.
     */
    public int send(short dest, byte[] data, int len) {
        // see how many frames we need
        int numFrames = (data.length + 2037) / 2038; // Round up division
        // Divide up data and add to send queue
        for (short i = 0; i < numFrames; i++) {
            // calculate the size of the current chunk
            int chunkSize = Math.min(2038, data.length - i * 2038);

            // create new data for frame
            byte[] dataChunk = new byte[chunkSize];
            int dataStart = i * 2038;

            // copy data into the chunk
            System.arraycopy(data, dataStart, dataChunk, 0, chunkSize);

            // Create new frame
            Frame outgoingFrame = new Frame(0, i, dest, ourMAC, dataChunk);
            //output.println("LinkLayer: Sending data - Dest: " + dest + ", Length: " + len);
            
            // Add to outgoing queue
            sendQueue.offer(outgoingFrame);
        }

        return len;
    }

    /**
     * Recv method blocks until data arrives, then writes it an address info into
     * the Transmission object.  See docs for full description.
     */

    public int recv(Transmission t) {
        // Create the Reader thread
    	//output.println("LinkLayer: Attempting to recieve data");
        // Check If incQueue 
    	while (true)
	    	while (incQueue.peek() != null) {
		    	try
		    	{
		            t = incQueue.take();
		            //output.println("LinkLayer: Found Val in Incoming Queue");
		            //Figure out if its too big
		            return t.getBuf().length;
		        }
		        catch (InterruptedException ie)
		        {
		            ie.printStackTrace();
		            return -1;
		        }
		    	//figure out max value
	    	}
    }

    /**
     * Returns a current status code.  See docs for full description.
     */
    public int status() {
        output.println("LinkLayer: Faking a status() return value of 0");
        return 0;
    }

    /**
     * Passes command info to your link layer.  See docs for full description.
     */
    public int command(int cmd, int val) {
        output.println("LinkLayer: Sending command "+cmd+" with value "+val);
        return 0;
    }
}